
export type Bid = {
  id: string;
  project_id: string;
  name: string;
  version: number;
  status: string;
  currency: string;
  notes: string | null;
};

