// types/task.ts

export interface ProjectTask {
    task_id:number
    daily_rate:number
}