import { Plus } from "lucide-react";

import { createBidItem } from "@/actions/bids";
import { EditableCell } from "@/components/editable/EditableCell";
import EditableTaskCell from "@/components/editable/EditableTaskCell";
import { Button } from "@/components/ui/button";
import { calculateBidTotals } from "@/lib/bids/calculateBidTotals";
import { cost_type } from "@/app/(main)/projects/[projectID]/bids/constants";
import type {
  BidItem,
  BidTaskLookup,
  ProjectTask,
  CalculatedBid,
} from "@/types/bid";

type BidItemsTableProps = {
  projectID: string;
  bidID: string;
  bidItems: BidItem[];
  bidTasks: BidTaskLookup;
  projectTasks: ProjectTask[];
  calculatedBid: ReturnType<typeof calculateBidTotals>;
};

const itemColumns = [
  { key: "name", label: "Name" },
  { key: "thumbnail", label: "Thumbnail" },
  { key: "frames", label: "Frames" },
  { key: "cost_type", label: "Cost Type" },
  { key: "description", label: "Description" },
  { key: "vendor_notes", label: "Vendor Notes" },
  { key: "foreign_spend", label: "Foreign Spend" },
];

const calculatedColumns = [
  { key: "item_cost", label: "Item Cost" },
  { key: "quantity", label: "Quantity" },
  { key: "total", label: "Total" },
];

export default function BidItemsTable({
  projectID,
  bidID,
  bidItems,
  bidTasks,
  projectTasks,
}: BidItemsTableProps) {
   return (
    <table className="w-full border-collapse text-sm">
      <div className="overflow-x-auto rounded-lg border border-slate-800">
        <table className="min-w-full text-sm">
          <thead>
            <tr>
              {itemColumns.map((column) => (
                <th
                  key={column.key}
                  className="border-b border-slate-700 bg-slate-900 px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide whitespace-nowrap"
                >
                  {column.label}
                </th>
              ))}

              {projectTasks.map((task) => (
                <th
                  key={task.task_id}
                  className="border-b border-slate-700 bg-slate-900 px-3 py-2 text-center text-xs font-semibold uppercase tracking-wide whitespace-nowrap"
                >
                  {task.name}
                </th>
              ))}

              {calculatedColumns.map((column) => (
                <th
                  key={column.key}
                  className="border-b border-slate-700 bg-slate-900 px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide whitespace-nowrap"
                >
                  {column.label}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {bidItems.length === 0 ? (
              <tr>
                <td
                  colSpan={
                    itemColumns.length +
                    projectTasks.length +
                    calculatedColumns.length
                  }
                  className="py-12 text-center text-slate-500"
                >
                  No items added to this bid.
                </td>
              </tr>
            ) : (
              bidItems.map((item) => {
                const taskLookup = bidTasks.get(item.id) ?? new Map();
                const calculatedItem = calculatedBid.items.get(item.id)!;

                return (
                  <tr
                    key={item.id}
                    className="border-b border-slate-800 hover:bg-slate-900/40"
                  >
                    <td className="px-3 py-2">
                      <EditableCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="item_code"
                        value={item.item_code}
                      />
                    </td>

                    <td className="px-4 py-3">
                      <EditableCell
                        table="bid_items"
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="item_code"
                        value={item.item_code}
                        type="text"
                        revalidatePath="/bids"
                      />
                    </td>

                    <td className="px-3 py-2">
                      {item.thumbnail_url ? (
                        <img
                          src={item.thumbnail_url}
                          alt=""
                          className="h-10 w-16 rounded object-cover"
                        />
                      ) : (
                        "-"
                      )}
                    </td>

                    <td className="px-3 py-2">
                      <EditableCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="frames"
                        value={item.frames}
                      />
                    </td>

                    <td className="px-3 py-2">
                      <EditableSelectCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        value={item.cost_type}
                        options={cost_type}
                        />
                    </td>

                    <td className="px-3 py-2">
                      <EditableCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="vfx_work_requirements"
                        value={item.vfx_work_requirements}
                      />
                    </td>

                    <td className="px-3 py-2">
                      <EditableCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="vendor_notes"
                        value={item.vendor_notes}
                      />
                    </td>

                    <td className="px-3 py-2">
                      <EditableCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="foreign_spend"
                        value={item.foreign_spend}
                      />
                    </td>

                    {projectTasks.map((task) => {
                      const taskData = taskLookup.get(
                        Number(task.task_id)
                      );

                      return (
                        <td
                          key={task.task_id}
                          className="px-3 py-2 text-center"
                        >
                          <EditableTaskCell
                            projectID={projectID}
                            bidID={bidID}
                            bidShotID={item.id}
                            taskID={Number(task.task_id)}
                            value={taskData?.duration_days ?? 0}
                          />
                        </td>
                      );
                    })}

                    <td className="px-3 py-2 text-right">
                      £
                      {calculatedItem.total.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </td>

                    <td className="px-3 py-2">
                      <EditableCell
                        projectID={projectID}
                        bidID={bidID}
                        itemID={item.id}
                        field="quantity"
                        value={item.quantity}
                      />
                    </td>

                    <td className="px-3 py-2 text-right font-medium">
                      £
                      {calculatedItem.total.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>{/* Paste the table here */}
    </>
  );
}